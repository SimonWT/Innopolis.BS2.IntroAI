% One spot

  % % % %
% W W W W %
% W W W W %
% W W W W %
% G W W W %
  % % % %

% walls
bump([_,1], south).
bump([_,4], north).
bump([1,_], west).
bump([4,_], east).

stench(X).

glint([1,1]).